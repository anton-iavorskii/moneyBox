--
-- PostgreSQL database dump
--

-- Dumped from database version 13.4 (Ubuntu 13.4-1.pgdg20.04+1)
-- Dumped by pg_dump version 13.4 (Ubuntu 13.4-1.pgdg20.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgraphile_watch; Type: SCHEMA; Schema: -; Owner: test
--

CREATE SCHEMA postgraphile_watch;


ALTER SCHEMA postgraphile_watch OWNER TO test;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: jwt_token; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.jwt_token AS (
	role text,
	user_id uuid
);


ALTER TYPE public.jwt_token OWNER TO postgres;

--
-- Name: notify_watchers_ddl(); Type: FUNCTION; Schema: postgraphile_watch; Owner: test
--

CREATE FUNCTION postgraphile_watch.notify_watchers_ddl() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
begin
  perform pg_notify(
    'postgraphile_watch',
    json_build_object(
      'type',
      'ddl',
      'payload',
      (select json_agg(json_build_object('schema', schema_name, 'command', command_tag)) from pg_event_trigger_ddl_commands() as x)
    )::text
  );
end;
$$;


ALTER FUNCTION postgraphile_watch.notify_watchers_ddl() OWNER TO test;

--
-- Name: notify_watchers_drop(); Type: FUNCTION; Schema: postgraphile_watch; Owner: test
--

CREATE FUNCTION postgraphile_watch.notify_watchers_drop() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
begin
  perform pg_notify(
    'postgraphile_watch',
    json_build_object(
      'type',
      'drop',
      'payload',
      (select json_agg(distinct x.schema_name) from pg_event_trigger_dropped_objects() as x)
    )::text
  );
end;
$$;


ALTER FUNCTION postgraphile_watch.notify_watchers_drop() OWNER TO test;

--
-- Name: get_user_id(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_user_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
SELECT current_setting('jwt.claims.user_id', TRUE)::uuid
$$;


ALTER FUNCTION public.get_user_id() OWNER TO postgres;

--
-- Name: signin(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.signin(email text, password text) RETURNS public.jwt_token
    LANGUAGE plpgsql STRICT SECURITY DEFINER
    AS $_$
DECLARE
        token_information jwt_token;
BEGIN
        SELECT (case when "isAdmin" = true THEN 'admin' ELSE 'user' END), id
               INTO token_information
               FROM "Users"
               WHERE "Users".email = $1
                     AND "Users"."password" = crypt($2, "Users"."password");
       RETURN token_information::jwt_token;
END;
$_$;


ALTER FUNCTION public.signin(email text, password text) OWNER TO postgres;

--
-- Name: signup(text, text); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.signup(email text, password text) RETURNS public.jwt_token
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
DECLARE
        token_information jwt_token;
BEGIN
        INSERT INTO "Users" (
			"email", 
			"password" 
		) 
		VALUES (
			$1, 
			crypt($2, gen_salt('bf', 12)) 
		);
        SELECT 'user', "Users".id
               INTO token_information
               FROM "Users"
               WHERE "Users".email = $1;
        RETURN token_information::jwt_token;
END;
$_$;


ALTER FUNCTION public.signup(email text, password text) OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Boxes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Boxes" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "userId" uuid NOT NULL,
    title character varying(255),
    amount integer NOT NULL,
    "time" integer NOT NULL,
    "createdAt" timestamp with time zone DEFAULT now()
);


ALTER TABLE public."Boxes" OWNER TO postgres;

--
-- Name: Payments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Payments" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    "boxId" uuid NOT NULL,
    "userId" uuid NOT NULL,
    value integer NOT NULL,
    status boolean DEFAULT false NOT NULL
);


ALTER TABLE public."Payments" OWNER TO postgres;

--
-- Name: Users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Users" (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    username character varying(255),
    email character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    "isAdmin" boolean,
    "createdAt" timestamp with time zone DEFAULT now()
);


ALTER TABLE public."Users" OWNER TO postgres;

--
-- Data for Name: Boxes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Boxes" (id, "userId", title, amount, "time", "createdAt") FROM stdin;
\.


--
-- Data for Name: Payments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Payments" (id, "boxId", "userId", value, status) FROM stdin;
\.


--
-- Data for Name: Users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Users" (id, username, email, password, "isAdmin", "createdAt") FROM stdin;
\.


--
-- Name: Boxes Boxes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Boxes"
    ADD CONSTRAINT "Boxes_pkey" PRIMARY KEY (id);


--
-- Name: Payments Payments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT "Payments_pkey" PRIMARY KEY (id);


--
-- Name: Users Users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT "Users_pkey" PRIMARY KEY (id);


--
-- Name: Boxes box_title_userId; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Boxes"
    ADD CONSTRAINT "box_title_userId" UNIQUE (title, "userId");


--
-- Name: Users users_email; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Users"
    ADD CONSTRAINT users_email UNIQUE (email);


--
-- Name: Boxes boxes_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Boxes"
    ADD CONSTRAINT boxes_users FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE CASCADE NOT VALID;


--
-- Name: Payments payments_boxes; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT payments_boxes FOREIGN KEY ("boxId") REFERENCES public."Boxes"(id) ON DELETE CASCADE;


--
-- Name: Payments payments_users; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Payments"
    ADD CONSTRAINT payments_users FOREIGN KEY ("userId") REFERENCES public."Users"(id) ON DELETE CASCADE;


--
-- Name: FUNCTION get_user_id(); Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON FUNCTION public.get_user_id() TO "user";


--
-- Name: TABLE "Boxes"; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Boxes" TO "user";
GRANT ALL ON TABLE public."Boxes" TO admin;


--
-- Name: TABLE "Payments"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE public."Payments" TO admin;
GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Payments" TO "user";


--
-- Name: TABLE "Users"; Type: ACL; Schema: public; Owner: postgres
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public."Users" TO "user";
GRANT ALL ON TABLE public."Users" TO admin;


--
-- Name: postgraphile_watch_ddl; Type: EVENT TRIGGER; Schema: -; Owner: test
--

CREATE EVENT TRIGGER postgraphile_watch_ddl ON ddl_command_end
         WHEN TAG IN ('ALTER AGGREGATE', 'ALTER DOMAIN', 'ALTER EXTENSION', 'ALTER FOREIGN TABLE', 'ALTER FUNCTION', 'ALTER POLICY', 'ALTER SCHEMA', 'ALTER TABLE', 'ALTER TYPE', 'ALTER VIEW', 'COMMENT', 'CREATE AGGREGATE', 'CREATE DOMAIN', 'CREATE EXTENSION', 'CREATE FOREIGN TABLE', 'CREATE FUNCTION', 'CREATE INDEX', 'CREATE POLICY', 'CREATE RULE', 'CREATE SCHEMA', 'CREATE TABLE', 'CREATE TABLE AS', 'CREATE VIEW', 'DROP AGGREGATE', 'DROP DOMAIN', 'DROP EXTENSION', 'DROP FOREIGN TABLE', 'DROP FUNCTION', 'DROP INDEX', 'DROP OWNED', 'DROP POLICY', 'DROP RULE', 'DROP SCHEMA', 'DROP TABLE', 'DROP TYPE', 'DROP VIEW', 'GRANT', 'REVOKE', 'SELECT INTO')
   EXECUTE FUNCTION postgraphile_watch.notify_watchers_ddl();


ALTER EVENT TRIGGER postgraphile_watch_ddl OWNER TO test;

--
-- Name: postgraphile_watch_drop; Type: EVENT TRIGGER; Schema: -; Owner: test
--

CREATE EVENT TRIGGER postgraphile_watch_drop ON sql_drop
   EXECUTE FUNCTION postgraphile_watch.notify_watchers_drop();


ALTER EVENT TRIGGER postgraphile_watch_drop OWNER TO test;

--
-- PostgreSQL database dump complete
--

